from pinecone import Pinecone, ServerlessSpec

pc = Pinecone(api_key="pcsk_5UQiMw_J6tjG9M2ocayQUd3ywAocHeamGmPpkdzpk4aXgCKRuEUvq9F9B9XhRtCzUVFB3A")

# Delete existing index if needed
if "sciscinet-entity" in pc.list_indexes().names():
    pc.delete_index("sciscinet-entity")

# Create a new index with 1536 dimensions
pc.create_index(
    name="sciscinet-entity",
    dimension=1536,
    metric="cosine",  # or 'dotproduct' or 'euclidean'
    spec=ServerlessSpec(cloud="aws", region="us-east-1")
)
