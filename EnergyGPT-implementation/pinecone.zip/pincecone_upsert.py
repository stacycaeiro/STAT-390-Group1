import os
from pinecone import Pinecone, ServerlessSpec
import openai
from uuid import uuid4
from openai import OpenAI

# === CONFIG ===
PINECONE_API_KEY = "pcsk_5UQiMw_J6tjG9M2ocayQUd3ywAocHeamGmPpkdzpk4aXgCKRuEUvq9F9B9XhRtCzUVFB3A"
PINECONE_ENV = "us-east-1"  # e.g. "us-east1-gcp"
PINECONE_INDEX_NAME = "sciscinet-entity"

OPENAI_API_KEY = "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"
EMBEDDING_MODEL = "text-embedding-3-small"

# === Set API keys ===
openai.api_key = OPENAI_API_KEY
pc = Pinecone(api_key=PINECONE_API_KEY)
index = pc.Index(PINECONE_INDEX_NAME)
client = OpenAI(api_key=OPENAI_API_KEY)

# === Delete records (uncomment this section if you want to delete everything ===
##index.delete(delete_all=True)
##print("🧽 All records deleted.")

# === Define embedding function ===
def get_embedding(text):
    response = openai.embeddings.create(
        input=[text],
        model=EMBEDDING_MODEL
    )
    return response.data[0].embedding

# === Example prompt-response pair ===
pairs = [
    {
        "prompt" : "Which 5 states currently house the most power plant facilities?",
        "response" : """(DatabaseSpecialist) The top 5 states with the most power plant facilities are:
                        Texas (TX) with 571 facilities
                        Florida (FL) with 473 facilities
                        New York (NY) with 374 facilities
                        Illinois (IL) with 370 facilities
                        Note: There is a significant number of entries with missing state information (503 facilities)."""
        },
    {
        "prompt" : "What are the most common primary and secondary fuel types used across power plant units?",
        "response" : """(DatabaseSpecialist) The dataset power_generation contains information on power plant fuel types. Here's a summary:
                        Number of Records: 333,860
                        Unique Primary Fuel Types: 14
                        Unique Secondary Fuel Types: 24
                        Most Common Primary Fuel Type: Pipeline Natural Gas
                        Most Common Secondary Fuel Type: NG"""
        },
    {
        "prompt" : "What state produces the most renewable energy?",
        "response" : """The state with the highest renewable energy production is North Carolina (NC) with a production of approximately 205,972 MWh.
                        Dataset references:
                        power_generation Parquet file located at data/input/power_generation.parquet."""
        },
    {
        "prompt" : "How many total power plant facilities are there across the US?",
        "response" : """I found a relevant dataset named power_generation in the local database. This dataset includes information about power plant facilities across the US. Here's a summary of the dataset:
                        Total Number of Power Plant Facilities: 1,671 unique facilities.
                        If you need more detailed information or further analysis, please let me know! If you require additional data, external sources like the EIA Open Data or FERC eLibrary can be useful for further investigation."""
        }]
        
        

# === Create vector and upsert ===
vectors = []

for pair in pairs:
    embedding = get_embedding(pair["prompt"])
    vectors.append({
        "id": str(uuid4()),
        "values": embedding,
        "metadata": {
            "prompt": pair["prompt"],
            "response": pair["response"]
        }
    })

# Upload to Pinecone
index.upsert(vectors=vectors)
print(f"✅ Uploaded {len(vectors)} vectors to Pinecone!")


